r# Crop Yield Prediction (India)

This project predicts crop yield using MLP+CNN and LSTM models, integrated with a WordPress site via a Flask API.

## File Structure
- `api/`: Flask API, models, and preprocessing files
- `web/`: HTML form and dropdown data
- `train_model.py`: Trains both models
- `generate_dropdowns.py`: Creates dropdown_data.json

## Setup
1. **Install dependencies**:
   ```bash
   pip install -r api/requirements.txt 